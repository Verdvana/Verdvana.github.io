#!/bin/sh

eval `dbus export merlinclash`
source /koolshare/scripts/base.sh
source helper.sh

if [ "$merlinclash_enable" == "1" ];then
	echo_date 关闭clash插件！
	sh /koolshare/merlinclash/clashconfig.sh stop
    sleep 1
fi


find /koolshare/init.d/ -name "*clash*" | xargs rm -rf
rm -rf /koolshare/bin/clash
rm -rf /koolshare/bin/yq
rm -rf /koolshare/bin/haveged_c
rm  /tmp/upload/yamls.txt
rm -rf /koolshare/res/icon-merlinclash.png
rm -rf /koolshare/res/clash-dingyue.png
rm -rf /koolshare/res/clash-kcp.jpg
rm -rf /koolshare/res/merlinclash.css
rm -rf /koolshare/res/mc-tablednd.js
rm -rf /koolshare/res/mc-menu.js
rm -rf /koolshare/res/clash*
rm -rf /koolshare/merlinclash/Country.mmdb
rm -rf /koolshare/merlinclash/clashconfig.sh
rm -rf /koolshare/merlinclash/yaml_bak/*
rm -rf /koolshare/merlinclash/yaml/*
rm -rf /koolshare/merlinclash/dashboard/*
rm -rf /koolshare/scripts/clash*.sh
rm -rf /koolshare/scripts/openssl.cnf
rm -rf /koolshare/webs/Module_merlinclash.asp
rm -rf /koolshare/merlinclash
rm -f /koolshare/scripts/merlinclash_install.sh
rm -f /koolshare/scripts/uninstall_merlinclash.sh
#ipset flush music
#ipset destroy music

dbus remove merlinclash_proxygroup_version
dbus remove merlinclash_proxygame_version
dbus remove softcenter_module_merlinclash_install
dbus remove softcenter_module_merlinclash_version
dbus remove merlinclash_version_local
dbus remove merlinclash_patch_version

