#!/bin/sh

eval $(dbus export merlinclash)
source /koolshare/scripts/base.sh
source helper.sh
alias echo_date='echo 【$(date +%Y年%m月%d日\ %X)】:'

if [ "$merlinclash_enable" == "1" ]; then
    #echo_date "开始检查进程状态..."
    if [ ! -n "$(pidof httpd)" ]; then
        service restart_httpd
    fi
    if [ ! -n "$(pidof clash)" ]; then
        sh /koolshare/merlinclash/clashconfig.sh restart >/dev/null 2>&1 &
    #    echo_date "重启 Clash 进程"
    fi

fi
