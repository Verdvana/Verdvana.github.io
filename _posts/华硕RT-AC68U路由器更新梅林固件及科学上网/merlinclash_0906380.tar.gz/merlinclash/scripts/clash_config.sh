#!/bin/sh

eval `dbus export merlinclash`
source /koolshare/scripts/base.sh
source helper.sh
alias echo_date='echo 【$(TZ=UTC-8 date -R +%Y年%m月%d日\ %X)】:'

echo "" > /tmp/merlinclash_log.txt


if [ "$merlinclash_enable" == "1" ];then
	echo start >> /tmp/merlinclash_log.txt
	sh /koolshare/merlinclash/clashconfig.sh restart >> /tmp/merlinclash_log.txt
else
	echo stop >> /tmp/merlinclash_log.txt
	sh /koolshare/merlinclash/clashconfig.sh stop >> /tmp/merlinclash_log.txt
fi

echo BBABBBBC >> /tmp/merlinclash_log.txt


