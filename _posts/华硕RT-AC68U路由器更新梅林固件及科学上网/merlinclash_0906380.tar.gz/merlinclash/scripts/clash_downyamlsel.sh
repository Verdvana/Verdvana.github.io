#!/bin/sh

eval $(dbus export merlinclash)
source /koolshare/scripts/base.sh
source helper.sh

alias echo_date='echo 【$(date +%Y年%m月%d日\ %X)】:'
LOG_FILE=/tmp/merlinclash_log.txt

echo_date "download" >> $LOG_FILE
echo_date "定位文件" >> $LOG_FILE
filepath=/koolshare/merlinclash

filename=$(echo ${merlinclash_delyamlsel}.yaml)
echo_date "$filename" >> $LOG_FILE
mkdir -p /var/wwwext
cp -rf $filepath/$filename /www/ext/${merlinclash_delyamlsel}.htm
if [ -f /www/ext/${merlinclash_delyamlsel}.htm ]; then
	echo_date "文件已复制" >> $LOG_FILE
else
	echo_date "文件复制失败" >> $LOG_FILE
fi


